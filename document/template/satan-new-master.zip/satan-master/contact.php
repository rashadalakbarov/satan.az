<?php
    include("include/header.php");
?>
<script>
    $(function(){
        $("#contact").addClass("active");
    });
</script>
<section class="header-margin">
    <div class="container">
        <div class="row">
            <h1 class="text-uppercase mb-3 pageTitle">Əlaqə</h1>
            <div>
                <?php
                    $rules_list=mysqli_query($connect, "SELECT *  FROM parametres WHERE parametres_key='contact' ");
                    while($subparametres=mysqli_fetch_array($rules_list)){ ?>
                        <p><?php echo $subparametres["parametres_value"] ?></p>
                <?php   }
                ?>
            </div>
        </div>
    </div>
</section>
<?php
    include("include/footer.php");
?>