<?php
    include("include/header.php"); ?>

<section class="mt-3">
    <div class="container">
        <div class="row mb-3">
            <h5 class="card-title text-uppercase position-relative rulers" style="margin-left:7px">Bütün Elanlar</h5>
        </div>
    </div>
    <div class="container" id="pagination_data"></div>
</section>

<?php
    include("include/footer.php");
?>